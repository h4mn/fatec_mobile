package com.example.aula05;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.ColorSpace;
import androidx.transition.Visibility;
import java.util.ArrayList;

public class bdModelo extends SQLiteOpenHelper {

    SQLiteDatabase dataBase;

    public bdModelo(Context context) {
        super(context, getDbNome(), null, getDbVersao());
        dataBase = getWritableDatabase();
    }

    private static String dbNome = "dbCredencial";
    private static int dbVersao = 1;
    private static String Tabela = "tblCredencial";
    private static String Id = "idCredencial";
    private static String Nome = "nomeCredencial";
    private static String Cidade = "cidadeCredencial";
    private static String Estado = "estadoCredencial";
    private String CmdSQL = "";

    public static String getDbNome() {
        return dbNome;
    }

    public static int getDbVersao() {
        return dbVersao;
    }

    public static String getTabela() {
        return Tabela;
    }

    public static String getId() {
        return Id;
    }

    public static String getNome() {
        return Nome;
    }

    public static String getCidade() {
        return Cidade;
    }

    public static String getEstado() {
        return Estado;
    }

    public String getCmdSQL() {
        return CmdSQL;
    }

    public void setCmdSQL(String cmdSQL) {
    CmdSQL = cmdSQL;
    }

        public String criarTabela() {
            setCmdSQL("CREATE TABLE " + getTabela() + " (" +
                    getId() + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    getNome() + " TEXT, " +
                    getCidade() + " TEXT, " +
                    getEstado() + " TEXT" +
                    ")"
            );
            return getCmdSQL();
        }

        @Override
        public void onCreate (SQLiteDatabase db){
            db.execSQL(criarTabela());
            dataBase.execSQL(criarTabela());
        }

        @Override
        public void onUpgrade (SQLiteDatabase db,int oldVersion, int newVersion){

        }

        public void insert (String tabela, Modelo credencial) {
            ContentValues dados = new ContentValues();
            dados.put(getNome(), credencial.getNome());
            dados.put(getCidade(), credencial.getCidade());
            dados.put(getEstado(), credencial.getEstado());
            dataBase.insert(tabela, null, dados);
        }

    public ArrayList<Modelo> select(){
        String[] colunas = {getId(), getNome(), getCidade(), getEstado()};
        Cursor cursor = dataBase.query(getTabela(), colunas,null, null, null, null, null,
                null);
        ArrayList<Modelo> arrayCredencialModel = new ArrayList<>();
        while(cursor.moveToNext()){
            Modelo modelo = new Modelo();
            modelo.setId(cursor.getInt(0));
            modelo.setNome(cursor.getString(1));
            modelo.setCidade(cursor.getString(2));
            modelo.setEstado(cursor.getString(3));
            arrayCredencialModel.add(modelo);
        }
        return arrayCredencialModel;
    }

    public void update(String tabela, Modelo credencial){
        ContentValues dados = new ContentValues();
        dados.put(getNome(), credencial.getNome());
        dados.put(getCidade(), credencial.getCidade());
        dados.put(getEstado(), credencial.getEstado());
        dataBase.update(tabela, dados, getId() + "=" + credencial.getId(), null);
    }
    public void delete(String tabela, Modelo credencial)
    {
        dataBase.delete(tabela,getId() + "=" + credencial.getId(),null);
    }

    }
