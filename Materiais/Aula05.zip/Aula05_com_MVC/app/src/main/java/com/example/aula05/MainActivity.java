package com.example.aula05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView txtIdProg;
    EditText edtNomep;
    EditText edtCidadep;
    EditText edtEstadop;
    int quantidadeRegistros;
    int registroAtual;
    int idCredencialAtual;

    Modelo credencial = new Modelo();

    bdModelo bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtIdProg = (TextView) findViewById(R.id.txtNome);
        edtNomep = (EditText) findViewById(R.id.edtNome);
        edtCidadep = (EditText) findViewById(R.id.edtCidade);
        edtEstadop = (EditText) findViewById(R.id.edtEstado);
        carregarRegistroZero();
    }

    public void clickBtnDeletar(View v)
    {
        credencial.setId(idCredencialAtual);
        credencial.setNome(edtNomep.getText().toString());
        credencial.setCidade(edtCidadep.getText().toString());
        credencial.setEstado(edtEstadop.getText().toString());
        bd = new bdModelo(getApplicationContext());
        bd.delete(bd.getTabela(), credencial);
        limpar();
        carregarRegistroZero();
    }

    public void clickBtnAlterar(View v)
    {
        credencial.setId(idCredencialAtual);
        credencial.setNome(edtNomep.getText().toString());
        credencial.setCidade(edtCidadep.getText().toString());
        credencial.setEstado(edtEstadop.getText().toString());
        bd = new bdModelo(getApplicationContext());
        bd.update(bd.getTabela(), credencial);
        carregarRegistroZero();
    }

    public void clickBtnCadastrar(View v)
    {
        credencial.setNome(edtNomep.getText().toString());
        credencial.setCidade(edtCidadep.getText().toString());
        credencial.setEstado(edtEstadop.getText().toString());
        bd = new bdModelo(getApplicationContext());
        bd.insert(bdModelo.getTabela(), credencial);
        carregarRegistroZero();
    }

    public void clickBtnNovo(View v)
    {
        limpar();
    }

    public void limpar()
    {
        txtIdProg.setText("Nome:");
        edtNomep.setText("");
        edtCidadep.setText("");
        edtEstadop.setText("");
        edtNomep.requestFocus();
    }

    public void clickBtnAnterior(View v)
    {
        if(quantidadeRegistros != 0)
        {
            if(registroAtual > 0)
            {
                registroAtual = registroAtual - 1;
                carregarDados(registroAtual);
            }
        }
    }

    public void clickBtnProximo(View v)
    {
        if(quantidadeRegistros != 0)
        {
            if(registroAtual < quantidadeRegistros - 1)
            {
                registroAtual = registroAtual + 1;
                carregarDados(registroAtual);
            }
        }
    }

    public void carregarDados(int i) {
        bd = new bdModelo(getApplicationContext());
        ArrayList<Modelo> arrayCredencialModel;
        arrayCredencialModel = bd.select();
        quantidadeRegistros = arrayCredencialModel.size();
        if(quantidadeRegistros != 0){
            Modelo credencialModel = arrayCredencialModel.get(i);
            //txtIdProg.setText(String.valueOf(bdModelo.getNome())+ ":");
            idCredencialAtual = credencialModel.getId();
            edtNomep.setText(credencialModel.getNome());
            edtCidadep.setText(credencialModel.getCidade());
            edtEstadop.setText(credencialModel.getEstado());
        }
    }

    public void carregarRegistroZero(){
        registroAtual = 0;
        carregarDados(registroAtual);
    }

}